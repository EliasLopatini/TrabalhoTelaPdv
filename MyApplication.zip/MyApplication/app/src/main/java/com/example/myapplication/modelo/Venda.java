package com.example.myapplication.modelo;

import java.util.ArrayList;

public class Venda {

    private Cliente cliente;
    private Produto produto;
    private double quantidade;
    private double valorUnitarioDeVenda;
    private int QuantidadeDeParcelas;
    private int tipoDePagamento;

    public Venda() {
    }

    public Venda(Cliente cliente, ArrayList<Produto> produtos, double quantidade, double valorUnitarioDeVenda, int QuantidadeDeParcelas, int tipoDePagamento) {
        this.cliente = cliente;
        this.produto = produto;
        this.quantidade = quantidade;
        this.valorUnitarioDeVenda = valorUnitarioDeVenda;
        this.QuantidadeDeParcelas = QuantidadeDeParcelas;
        this.tipoDePagamento = tipoDePagamento;
    }

    public Cliente getCliente() {
        return cliente;
    }
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    public Produto getProduto() {
        return produto;
    }
    public void setProduto(Produto produto) {
        this.produto = produto;
    }
    public double getQuantidade() {
        return quantidade;
    }
    public void setQuantidade(double quantidade) {
        this.quantidade = quantidade;
    }
    public double getValorUnitarioDeVenda() {
        return valorUnitarioDeVenda;
    }
    public void setValorUnitarioDeVenda(double valorUnitarioDeVenda) {
        this.valorUnitarioDeVenda = valorUnitarioDeVenda;
    }
    public int getQuantidadeDeParcelas() {
        return QuantidadeDeParcelas;
    }
    public void setQuantidadeDeParcelas(int quantidadeDeParcelas) {
        this.QuantidadeDeParcelas = quantidadeDeParcelas;
    }
    public int getTipoDePagamento() {
        return tipoDePagamento;
    }
    public void setTipoDePagamento(int tipoDePagamento) {
        this.tipoDePagamento = tipoDePagamento;
    }
}
