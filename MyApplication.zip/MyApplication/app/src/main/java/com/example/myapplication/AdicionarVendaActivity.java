package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.modelo.Cliente;
import com.example.myapplication.modelo.ItemEmPedido;
import com.example.myapplication.modelo.Produto;

import java.util.ArrayList;
import java.util.Random;

public class AdicionarVendaActivity extends AppCompatActivity {

    private ArrayList<Cliente> listaCliente;
    private ArrayList<Produto> listaProduto;
    private ArrayList<ItemEmPedido> itemEmPedido;
    private Spinner spCliente;
    private Spinner spProduto;
    private TextView tvRetornaItens;
    private TextView tvRetornaQtdItens;
    private TextView tvRetornaTotalProd;
    private TextView tvRetornaParcela;
    private TextView tvRetornaTotalFinal;
    private TextView tvRetornaCodigo;
    private EditText edQuantProd;
    private EditText edValorProd;
    private EditText edQtdParcela;
    private ImageButton btAddProduto;
    private ImageButton btCancela;
    private ImageButton btFinaliza;
    private RadioButton rbVista;
    private RadioButton rbPrazo;
    private TextView tvErroProduto;
    private TextView tvErroCliente;
    private int posicaoSelecionadaP = 0;
    private int posicaoSelecionadaC = 0;
    private int posicaoSelecionada = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lancamento_pedido);

        spCliente = findViewById(R.id.spCliente);
        spProduto = findViewById(R.id.spProduto);
        edQuantProd = findViewById(R.id.edQuantProd);
        edValorProd = findViewById(R.id.edValorProd);

        btCancela = findViewById(R.id.btCancela);
        btAddProduto = findViewById(R.id.btAddProd);
        tvRetornaItens = findViewById(R.id.tvRetornaItens);
        tvRetornaQtdItens = findViewById(R.id.tvRetornaQtdItens);

        tvRetornaTotalProd = findViewById(R.id.tvRetornaTotalProd);
        rbVista = findViewById(R.id.rbVista);
        rbPrazo = findViewById(R.id.rbPrazo);
        edQtdParcela = findViewById(R.id.edQtdParcela);

        tvRetornaParcela = findViewById(R.id.tvRetornaParcela);
        tvRetornaTotalFinal = findViewById(R.id.tvRetornaTotalFinal);
        btFinaliza = findViewById(R.id.btFinaliza);

        tvErroCliente = findViewById(R.id.tvErroCliente);
        tvErroProduto = findViewById(R.id.tvErroProduto);
        tvRetornaCodigo = findViewById(R.id.tvRetornaCodigo);

        carregaCliente();
        carregaProduto();

        spCliente.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView,
                                       View view, int posicao, long l) {
                if(posicao > 0){
                    posicaoSelecionada = posicao;
                    tvErroCliente.setVisibility(View.GONE);
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spProduto.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView,
                                       View view, int posicao, long l) {
                if(posicao > 0){
                    posicaoSelecionada = posicao;
                    tvErroProduto.setVisibility(View.GONE);
                    exibeValorUnitario();

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }

        });

        btAddProduto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                adicionarItemVenda();
            }
        });

        btFinaliza.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //finalizaVenda();
            }

        });
    }

    private void carregaCliente() {
        listaCliente = Controller.getInstancia().retornarCliente();
        String[]vetCli = new String[listaCliente.size() + 1];
        vetCli[0] = "Selecione o Cliente";
        for (int i = 0; i < listaCliente.size(); i++) {
            Cliente cliente1 = listaCliente.get(i);
            vetCli[i+1] = cliente1.getNome();
        }
        ArrayAdapter adapter = new ArrayAdapter(
                AdicionarVendaActivity.this,
                android.R.layout.simple_dropdown_item_1line,
                vetCli);

        spCliente.setAdapter(adapter);

    }

    private void carregaProduto() {
        listaProduto = Controller.getInstancia().retornarProduto();
        String[]vetProd = new String[listaProduto.size() + 1];
        vetProd[0] = "Selecione o produto";
        for (int i = 0; i < listaProduto.size(); i++) {
            Produto produto1 = listaProduto.get(i);
            vetProd[i+1] = produto1.getCodigo()+" - "+produto1.getNomeProduto();
        }
        ArrayAdapter adapter = new ArrayAdapter(
                AdicionarVendaActivity.this,
                android.R.layout.simple_dropdown_item_1line,
                vetProd);

        spProduto.setAdapter(adapter);

    }

    private void exibeValorUnitario() {
        ArrayList<Produto> lista = Controller.getInstancia().retornarProduto();
        String exibeValorUni = "";
            exibeValorUni += lista.get(posicaoSelecionada -1).getValorUnitario();

        edValorProd.setText(exibeValorUni);
    }

    private void atualizaListaProduto(){
        ArrayList<ItemEmPedido> lista = Controller.getInstancia().retornaItemPedido();
        String texto = "";


        for (ItemEmPedido item : lista) {

            Produto prod = item.getProduto();

            texto += prod.getCodigo()+" - "+prod.getNomeProduto()+"\nQtd: "+item.getQuantidade()+
                    " - VL Un.: "+item.getValorDaVenda() + "\nVL Total: "+item.getValorDaVenda()*item.getQuantidade()+"\n";

        }

        tvRetornaItens.setText(texto);
    }

    private void adicionarItemVenda(){

        ItemEmPedido itemEmPedido = new ItemEmPedido();
        Produto prod = listaProduto.get(posicaoSelecionada -1);

        itemEmPedido.setProduto(prod);
        itemEmPedido.setQuantidade(Integer.parseInt(edQuantProd.getText().toString()));
        itemEmPedido.setValorDaVenda(Double.parseDouble(edValorProd.getText().toString()));

        Controller.getInstancia().salvarItemPedido(itemEmPedido);

        atualizaListaProduto();
    }


}