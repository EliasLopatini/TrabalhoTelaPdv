package com.example.myapplication.modelo;

public class Produto {
    private String codigo;
    private String nomeProduto;
    private double valorUnitario;
    public Produto() {
    }
    public Produto(String codigo, String nomeProduto, double valorUnitario) {
        this.codigo = codigo;
        this.nomeProduto = nomeProduto;
        this.valorUnitario = valorUnitario;
    }
    public String getCodigo() {
        return codigo;
    }
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    public String getNomeProduto() {
        return nomeProduto;
    }
    public void setNomeProduto(String nomeProduto) {
        this.nomeProduto = nomeProduto;
    }
    public double getValorUnitario() {
        return valorUnitario;
    }
    public void setValorUnitario(double valorUnitario) {
        this.valorUnitario = valorUnitario;
    }
}
