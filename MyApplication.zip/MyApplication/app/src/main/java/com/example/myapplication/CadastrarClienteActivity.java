package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.modelo.Cliente;


public class CadastrarClienteActivity extends AppCompatActivity {

    private EditText edNomeCliente;
    private EditText edCpfCliente;

    private Button btSalvarCliente;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_cliente);

        edNomeCliente = findViewById(R.id.edNomeCliente);
        edCpfCliente = findViewById(R.id.edCpfCliente);
        btSalvarCliente = findViewById(R.id.btGravarC);


        btSalvarCliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvarCliente();
            }
        });
    }

    private void salvarCliente(){
        if(edNomeCliente.getText().toString().isEmpty()){
            edNomeCliente.setError("Informe o nome do cliente!");
            return;
        }
        if (edCpfCliente.getText().toString().isEmpty()){
            edCpfCliente.setError("Informe o CPF do cliente!");
            return;
        }

        Cliente cliente = new Cliente();
        cliente.setNome(edNomeCliente.getText().toString());
        cliente.setCpf(edCpfCliente.getText().toString());

        Controller.getInstancia().salvarCliente(cliente);

        Toast.makeText(CadastrarClienteActivity.this, "Cliente Cadastrado com sucesso!", Toast.LENGTH_LONG).show();

        this.finish();

    }
}