package com.example.myapplication;

import com.example.myapplication.modelo.Cliente;
import com.example.myapplication.modelo.ItemEmPedido;
import com.example.myapplication.modelo.Produto;
import com.example.myapplication.modelo.Venda;

import java.util.ArrayList;

public class Controller {

    private static Controller instancia;

    private ArrayList<Cliente> listaCliente;
    private ArrayList<Produto> listaProduto;
    private ArrayList<Venda> listaVenda;

    private ArrayList<ItemEmPedido> listaItemEmPedido;


    public static Controller getInstancia(){
        if (instancia == null){
            return instancia = new Controller();
        }else{
            return instancia;
        }
    }

    private Controller() {
        listaCliente = new ArrayList<>();
        listaProduto = new ArrayList<>();
        listaVenda = new ArrayList<>();
        listaItemEmPedido = new ArrayList<>();

    }

    public void salvarCliente( Cliente cliente) {
        listaCliente.add(cliente);
    }

    public ArrayList<Cliente> retornarCliente(){
        return listaCliente;
    }



    public void salvarProduto( Produto produto){
        listaProduto.add(produto);
    }
    public ArrayList<Produto> retornarProduto(){
        return listaProduto;
    }



    public void salvarVenda(Venda venda){
        listaVenda.add(venda);
    }
    public ArrayList<Venda> retornarVenda(){
        return listaVenda;
    }


    public void salvarItemPedido(ItemEmPedido itemEmPedido){
        listaItemEmPedido.add(itemEmPedido);
    }

    public ArrayList<ItemEmPedido> retornaItemPedido(){ return listaItemEmPedido;}

}
